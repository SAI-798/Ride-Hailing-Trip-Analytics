"""
OPTIONAL local test (not needed on Databricks).
Runs the SAME 02/03/04 SQL files in DuckDB on your laptop to catch typos
and logic errors before you open Databricks.

Run:  pip install duckdb ;  python tests/local_duckdb_check.py

What it changes to make Databricks SQL run in DuckDB:
  * STREAMING TABLE / MATERIALIZED VIEW  -> plain table
  * TEMPORARY VIEW                       -> view
  * removes CONSTRAINT blocks and COMMENT lines
  * adds an INITCAP function (DuckDB has none)
  * removes the mobility_catalog.trips. prefix
It does NOT test read_files, streaming, or the pipeline UI.
"""
import re, sys, pathlib, duckdb

root = pathlib.Path(__file__).resolve().parent.parent
con = duckdb.connect()

# INITCAP like Spark: first letter of each space-separated word upper, rest lower
con.execute("""
CREATE MACRO initcap(s) AS array_to_string(
  list_transform(string_split(lower(s), ' '),
                 lambda x: upper(x[1:1]) || x[2:]), ' ')
""")

# Bronze: everything as text, like the pipeline does
con.execute(f"""
CREATE TABLE bronze_ride_trips AS
SELECT *, 'ride_trips_raw.csv' AS source_file, now() AS ingested_at
FROM read_csv('{root / "data" / "ride_trips_raw.csv"}', header=true, all_varchar=true)
""")

def translate(sql: str) -> str:
    sql = re.sub(r"--[^\n]*", "", sql)                                   # comments
    sql = re.sub(r"\n\(\s*CONSTRAINT.*?\n\)\s*\n", "\n", sql, flags=re.S)  # constraints
    sql = re.sub(r"\nCOMMENT '[^']*'", "", sql)
    sql = sql.replace("mobility_catalog.trips.", "")
    sql = sql.replace("CREATE TEMPORARY VIEW", "CREATE OR REPLACE VIEW")
    sql = re.sub(r"CREATE OR REFRESH MATERIALIZED VIEW", "CREATE OR REPLACE TABLE", sql)
    sql = re.sub(r"CREATE OR REPLACE TABLE (\w+)\s*AS", r"CREATE OR REPLACE TABLE \1 AS", sql)
    return sql

for f in ["02_silver.sql", "03_gold.sql"]:
    for stmt in translate((root / "sql" / f).read_text()).split(";"):
        if stmt.strip():
            con.execute(stmt)

# Part A of 04_validation.sql = the first statement
val = translate((root / "sql" / "04_validation.sql").read_text()).split(";")[0]
rows = con.execute(val).fetchall()
bad = 0
for name, actual, expected, status in rows:
    print(f"{status:5} {name}  (actual={actual}, expected={expected})")
    bad += status != "PASS"
print("\nALL CHECKS PASSED" if bad == 0 else f"\n{bad} CHECK(S) FAILED")
print("\nreject reasons:", con.execute("select reject_reason, count(*) from silver_trips_rejected group by 1").fetchall())
print("gold_data_quality:", con.execute("select * from gold_data_quality").fetchdf().T.to_string())
print(con.execute("select * from gold_data_issues").fetchdf().to_string())
sys.exit(1 if bad else 0)
