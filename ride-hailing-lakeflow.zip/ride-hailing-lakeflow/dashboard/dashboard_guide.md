# Dashboard guide: Databricks AI/BI (3 pages)

**Why AI/BI:** it is built into Databricks Free Edition, so no extra install and no
connection setup. (Power BI notes at the bottom.)
The dashboard reads **only Gold tables**. That is the whole point of Gold.

> Button names in Databricks change from time to time. If a name below does not match,
> look for the closest one. I could not click through the Databricks UI myself, so the
> settings are written from the documented AI/BI features. Treat every widget setting
> as "try this" and adjust.

## Step 0: create the dashboard and the datasets
1. Left menu **Dashboards** > **Create dashboard**. Name it `Ride-Hailing Trips Analytics`.
2. Open the **Data** tab > **Create from SQL**.
3. For every `-- DATASET:` block in `dashboard_queries.sql`, paste the query, **Run**, and
   rename the dataset to the label (e.g. `ds_kpi`).

✅ **Checkpoint 0:** you have 9 datasets: `ds_kpi, ds_monthly, ds_city, ds_vehicle, ds_payment,
ds_channel, ds_pending, ds_dq, ds_issues`. `ds_kpi` returns one row.

## Page 1: Overview
Rename the page tab to **Overview** (Canvas tab, page name at the bottom or top).

| Visual | Dataset | Settings | Expected value |
|---|---|---|---|
| Counter: **Total Trips** | ds_kpi | Value = `total_trips`, format number, no decimals | **1,168** |
| Counter: **Net Revenue (₹)** | ds_kpi | Value = `net_revenue`, format number, 2 decimals | **237,150.58** |
| Counter: **Total Distance (km)** | ds_kpi | Value = `total_km` | **15,769.1** |
| Counter: **Platform Earnings (₹)** | ds_kpi | Value = `platform_earnings` | **52,639.56** |
| Line chart: **Net revenue by month** | ds_monthly | X = `trip_month` (set to **Monthly**), Y = `net_revenue` (Sum). Title and axis titles on | 12 points, Jan to Dec 2025 |
| Bar chart: **Net revenue by city** | ds_city | X = `city`, Y = `net_revenue` (Sum), Color = `region`, sort Y descending | Bengaluru highest (43,393.63) |
| Filter: **Region** | ds_city | Filter widget on `region`, multiple select | Only affects visuals using `ds_city` |

✅ **Checkpoint 1:** Total Trips card = 1,168 and the line chart has 12 points. If the card says
1,214 you used Bronze, go back and check the dataset query.

## Page 2: Products and Payments (add a new page, name it)
| Visual | Dataset | Settings | Expected |
|---|---|---|---|
| Bar: **Trips by vehicle type** | ds_vehicle | X = `vehicle_type`, Y = `trips` (Sum) | Mini 304, Auto 259, Sedan 248, Bike 245, Premium 112 |
| Bar: **Net revenue by vehicle type** | ds_vehicle | X = `vehicle_type`, Y = `net_revenue` | Mini 68,193.19 highest |
| Bar: **Average rating by vehicle type** | ds_vehicle | X = `vehicle_type`, Y = `avg_rating` with aggregation set to **Average** or *no aggregation* (one row per vehicle). Y axis min 3.5, max 4.5 | Auto 4.10 highest |
| Bar: **Trips by payment method** | ds_payment | X = `payment_method`, Y = `trips` | UPI 534 |
| Bar: **Trips by booking channel** | ds_channel | X = `booking_channel`, Y = `trips` | App 920 |
| Counter: **Pending amount (₹)** | ds_pending | Value = `pending_amount` | **18,746.19** |

⚠️ **Never SUM or AVERAGE the averages.** `avg_rating` already has one row per vehicle, so
use it as it is. A truncated Y axis (3.5 to 4.5) exaggerates small differences; add the axis title and say so in the README.

✅ **Checkpoint 2:** the five vehicle trip bars add up to 1,168.

## Page 3: Data Quality
| Visual | Dataset | Settings | Expected |
|---|---|---|---|
| Counter: **Bronze rows** | ds_dq | `bronze_rows` | 1,214 |
| Counter: **Clean trips** | ds_dq | `clean_rows` | 1,168 |
| Counter: **Rejected rows** | ds_dq | `rejected_rows` | 22 |
| Counter: **Duplicates removed** | ds_dq | `duplicate_rows` | 24 |
| Counter: **Reconciliation passed?** | ds_dq | `reconciliation_passed` | **Yes** |
| Bar (horizontal): **Rows affected by each problem** | ds_issues | Y = `issue`, X = `rows_affected`, sort descending | Messy text 155 is longest |
| Table: **What we did about it** | ds_issues | columns `issue`, `rows_affected`, `action_taken` | 9 rows |

✅ **Checkpoint 3:** 1,214 = 1,168 + 22 + 24. You can read the equation straight off the page.

## Publish
Click **Publish**. Take the screenshots in the README checklist **after** publishing.
Optional: add a schedule to refresh after the pipeline.

## Power BI option (not built or tested here)
Get Data > Azure Databricks, enter server hostname and HTTP path from your SQL warehouse, load the
same Gold tables, build the same three pages. The `ds_*` queries above work as **Native Query / SQL
statement** if you prefer one table per visual.
