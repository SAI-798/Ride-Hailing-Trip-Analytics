# LinkedIn post draft (about 150 words)

I just finished my first end-to-end data engineering project on Databricks. 🚕

The data: a messy, made-up ride-hailing export with 1,214 trips. It had spaces, mixed capitals, blanks, duplicate trips and impossible distances.

What I built with SQL and Lakeflow Spark Declarative Pipelines:
• Bronze: the raw file, untouched
• Silver: cleaned trips, plus a rejected table that keeps every bad row with its reason
• Gold: summaries by month, city, vehicle and payment method
• A 3-page dashboard on top

My favourite part: a reconciliation check. 1,214 = 1,168 clean + 22 rejected + 24 duplicates. I counted duplicates a different way than the pipeline did, and when I broke my own rule on purpose the check failed. A test that can't fail proves nothing.

Lessons: use TRY_CAST instead of crashing, never INITCAP a payment method (UPI ≠ Upi), and never delete bad data silently.

Code and README: [your GitHub link]

#DataEngineering #Databricks #SQL #LearningInPublic
