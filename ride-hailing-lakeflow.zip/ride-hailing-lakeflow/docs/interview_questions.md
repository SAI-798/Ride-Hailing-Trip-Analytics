# 8 interview questions about this project

**1. Why keep a Bronze layer instead of cleaning the CSV directly?**
Bronze is the untouched copy. If a cleaning rule is wrong, I fix it and re-run from Bronze without asking for the file again, and every number can be traced to a source row.

**2. Why did you read every Bronze column as STRING?**
One bad value like `abc` in distance would otherwise fail the load or change types. Reading text and using `TRY_CAST` in Silver turns bad values into `NULL`, and my rules then reject them with a reason.

**3. What is the difference between a rejected row and a duplicate?**
A rejected row breaks a business rule (distance <= 0, negative rate). A duplicate is a valid trip that appears twice. Both are kept in their own tables, never deleted silently, but they are counted separately in the reconciliation.

**4. How does your reconciliation prove no row was lost, and why is it a real test?**
`bronze = clean + rejected + duplicates` (1,214 = 1,168 + 22 + 24). Duplicates are counted independently on Bronze with `COUNT(*) - COUNT(DISTINCT trip_id)`, while clean and rejected come from the Silver window logic. I tested by breaking the dedupe rule and the check failed.

**5. Why `trip_id` for duplicates and not `customer_id`?**
`trip_id` is unique per trip. A customer or driver has many trips, so using their ID would delete real trips.

**6. Why TRIM before INITCAP, and why no INITCAP on payment_method?**
TRIM removes spaces first so `"  mumbai "` and `"Mumbai"` match. INITCAP would change `UPI` to `Upi`, which splits one payment method into two groups and breaks the chart.

**7. Why is a blank rating left as NULL, not 0?**
`AVG` ignores `NULL`, so the average uses only real ratings. A 0 is a fake rating and pulls every average down. I also store `rated_trips` so you can see how many ratings the average is based on.

**8. Which vehicle earns the most and which is rated best?**
Mini earns the most (₹68,193.19) and Auto has the best average rating (4.10). Ratings differ by only about 0.14 between vehicles, so I would not claim a big quality difference. Revenue follows trip count and distance (Mini 304 trips; Bike earns least with the shortest trips).
