# Click-by-click Databricks guide (Free Edition)

> I could not log in to Databricks, so the menu names below come from the documented UI and may
> differ slightly. The SQL logic itself was tested locally (see README). Whenever a step says
> **Checkpoint**, stop and confirm before moving on.

**Names used (change in one place if you must):** catalog `mobility_catalog`, schema `trips`,
volume `raw_files`. Volume path: `/Volumes/mobility_catalog/trips/raw_files/`.
If you use another catalog (such as `workspace`), search and replace `mobility_catalog` in every file.
*(Your template said `/Volumes/<CATALOG>/default/<VOLUME>`. I used the schema `trips` from your project brief. Either works if all files agree.)*

## Part 1: Setup
1. Log in to Databricks Free Edition. Left menu > **SQL Editor** > new query.
2. Paste the first 3 statements of `00_setup.sql` (catalog, schema, volume). Select one statement at a time and click **Run**.
   - ✅ **Checkpoint 1:** no red error. If `CREATE CATALOG` fails, use the `workspace` option written inside the file.
3. Left menu **Catalog** > `mobility_catalog` > `trips` > `raw_files` > **Upload to this volume** > pick `ride_trips_raw.csv`.
4. Back in the SQL Editor run `LIST '/Volumes/...'`, the preview, and the count.
   - ✅ **Checkpoint 2:** the file is listed, preview shows messy cities like `  bengaluru`, count = **1214**.

## Part 2: Create the pipeline
5. Left menu **Jobs & Pipelines** > **Create** > **ETL pipeline**.
6. Name `ride_trips_pipeline`. Default catalog `mobility_catalog`, default schema `trips`. Choose **SQL** and start with an empty file / "add existing assets" (the wording varies).
7. Create three SQL files in the pipeline folder and paste: `01_bronze.sql`, `02_silver.sql`, `03_gold.sql`.
   - **Why default catalog and schema?** The files use short table names such as `bronze_ride_trips`; the pipeline adds the catalog and schema.
8. Click **Run pipeline** (run the whole pipeline, not a single file; each file uses tables from the others).
   - ✅ **Checkpoint 3:** the graph shows all objects green: 1 bronze, 3 silver, 6 gold. Bronze shows **1,214** rows written.
9. Click `silver_trips_clean` in the graph > check the data quality / expectations: all 4 constraints should show **0** violations.
   - ✅ **Checkpoint 4:** `silver_trips_clean` = **1,168** rows.

## Part 3: Validate
10. SQL Editor: paste Part A of `04_validation.sql` and run.
    - ✅ **Checkpoint 5:** all 29 rows say **PASS**. Any FAIL: run the Part B query for that topic.
11. Run `SELECT * FROM mobility_catalog.trips.gold_data_quality;`
    - ✅ **Checkpoint 6:** 1214 / 24 / 1168 / 22 / diff 0 / **Yes**.

## Part 4: Dashboard
12. Follow `dashboard/dashboard_guide.md` (checkpoints 0 to 3 are inside).

## Part 5: GitHub
13. Create a repo, upload the folder (web **Add file > Upload files** is fine), add the screenshots into `docs/screenshots/`, and link them in the README.

## Common errors and fixes

| What you see | Why | Fix |
|---|---|---|
| `CREATE CATALOG` fails (storage root / permission) | Free Edition may not allow new managed catalogs | Use the built-in `workspace` catalog, replace the name everywhere |
| Path not found / no files | Wrong volume name or the upload went to another folder | Run `LIST '/Volumes/.../raw_files/'`; check spelling and case |
| Bronze has 0 rows on a re-run after re-uploading | Streaming tables remember which files they read | Run pipeline with **Full refresh** (menu next to Run), or upload with a new file name |
| `Table or view not found: bronze_ride_trips` | Default catalog/schema not set, or only one file was run | Edit pipeline settings; run the whole pipeline |
| Cannot query `trips_labeled` in SQL Editor | It is a temporary view that exists only inside the pipeline | Expected. Query `silver_trips_rejected` instead |
| Columns shifted or wrong types | Schema guessed from the file | Bronze sets all 20 columns as STRING on purpose; keep the order of the CSV |
| `UPI` became `Upi` | INITCAP applied to payment method | Remove INITCAP there. Validation check 15 catches this |
| Dashboard says 1,214 trips | A dashboard dataset reads Bronze | Point it to a Gold table |
| Ratings average looks wrong | Averaging averages, or blank rating became 0 | Use `gold_vehicle_summary.avg_rating`; validation check 21 |
| Pipeline will not start / is slow | Free Edition compute limits, serverless start-up | Wait, retry later; do not click Run repeatedly |
| Validation check 01 to 04 FAIL but the rest PASS | You used a different CSV | Replace the expected numbers with your own profile |

## What I could not test (please verify yourself)
* `read_files` with `schema =>` inside `STREAM(...)`, and `_metadata.file_name` in Bronze.
* `CREATE TEMPORARY VIEW` plus window function inside a pipeline.
* `CONSTRAINT ... EXPECT` on materialized views.
* `CREATE CATALOG` on your Free Edition workspace.
* All dashboard widget names and settings.
* Spark `INITCAP` on every odd case; I tested the same rules in DuckDB with an equivalent function.

If any of these fail, send me the exact error text and I will fix the file.
